'use strict';
const MAX = 64 * 1024;
const EVENTS = new Set(["SessionStart","UserPromptSubmit","PreToolUse","PostToolUse","Notification","Stop","StopFailure","StopCancelled"]);
const MAX_ID = 160;
const MAX_TEXT = 20000;
const allowed = (value, max) => typeof value === 'string' && value.trim() && value.trim().length <= max ? value.trim() : undefined;
const hasText = (value) => typeof value === 'string' && value.trim().length > 0;
const pick = (input, keys) => {
  for (const key of keys) if (input[key] !== undefined) return input[key];
};
const finish = (ok) => { if (ok) process.stdout.write('{}'); };
const event = process.argv[2];
let size = 0;
let overflow = false;
const chunks = [];
process.stdin.on('data', (chunk) => {
  if (overflow) return;
  size += chunk.length;
  if (size > MAX) { overflow = true; return; }
  chunks.push(chunk);
});
process.stdin.on('error', () => finish(false));
process.stdin.on('end', async () => {
  if (overflow || !EVENTS.has(event)) return finish(false);
  let input;
  try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return finish(false); }
  if (!input || typeof input !== 'object' || Array.isArray(input)) return finish(false);
  if (hasText(pick(input, ['subagentType', 'subagent_type', 'agent_id', 'agent_type']))) return finish(false);
  const session = allowed(pick(input, ['sessionId', 'session_id']), MAX_ID);
  if (!session) return finish(false);
  const body = { session_id: session, hook_event_name: event };
  const source = event === 'SessionStart' ? allowed(pick(input, ['source']), MAX_ID) : undefined;
  const prompt = event === 'UserPromptSubmit' ? allowed(pick(input, ['prompt']), MAX_TEXT) : undefined;
  const tool = event === 'PreToolUse' || event === 'PostToolUse' ? allowed(pick(input, ['toolName', 'tool_name']), MAX_ID) : undefined;
  const toolUseId = event === 'PreToolUse' || event === 'PostToolUse' ? allowed(pick(input, ['toolUseId', 'tool_use_id']), MAX_ID) : undefined;
  const notification = event === 'Notification' ? allowed(pick(input, ['notificationType', 'notification_type']), MAX_ID) : undefined;
  const reason = event === 'Stop' || event === 'StopFailure' || event === 'StopCancelled' ? allowed(pick(input, ['reason']), MAX_ID) : undefined;
  if (source) body.source = source;
  if (prompt) body.prompt = prompt;
  if (tool) body.tool_name = tool;
  if (toolUseId) body.tool_use_id = toolUseId;
  if (notification) body.notification_type = notification;
  if (reason) body.reason = reason;
  const base = process.env.AGENT_OFFICE_HOOK_URL;
  const token = process.env.AGENT_OFFICE_HOOK_TOKEN;
  const worker = process.env.AGENT_OFFICE_WORKER_ID;
  if (!base || !token || !worker) return finish(false);
  try {
    const url = new URL('/hooks/grok', base);
    url.searchParams.set('worker', worker);
    url.searchParams.set('event', event);
    const response = await fetch(url, {
      method: 'POST',
      headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(2000),
    });
    finish(response.ok);
  } catch { finish(false); }
});
