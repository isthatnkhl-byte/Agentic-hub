export {}; // a module, so its names don't clash with the other pages' scripts

const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const urlParams = new URLSearchParams(location.search);
const codeOrToken = location.hash.slice(1) || urlParams.get('code') || '';

const form = $<HTMLFormElement>('form');
const codeInput = $<HTMLInputElement>('code');
const nameInput = $<HTMLInputElement>('name');
const passwordInput = $<HTMLInputElement>('password');
const submitBtn = $<HTMLButtonElement>('submit');
const errorEl = $('error');

if (codeOrToken) {
  codeInput.value = codeOrToken;
}

try {
  const savedName = localStorage.getItem('agent-office.login-name') || '';
  if (savedName && !nameInput.value) nameInput.value = savedName;
} catch {
  // storage blocked
}

async function post(body: Record<string, unknown>): Promise<{ ok: boolean; body: any }> {
  const res = await fetch('/api/join', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { ok: res.ok, body: await res.json().catch(() => ({})) };
}

async function checkCode(val: string) {
  if (!val) return;
  try {
    const r = await post({ token: val, code: val, peek: true });
    if (!r.ok) {
      errorEl.textContent = r.body.error ?? 'Invalid room code or invite link';
      return;
    }
    const { name: invited, role, by, project, roomCode } = r.body;
    $('title').textContent = roomCode ? `Join ${project} (${roomCode})` : `Join the ${project} office`;
    $('sub').textContent = roomCode
      ? `Step into the 3D office to work on ${project} with your team.`
      : `${by} invited you${role === 'admin' ? ' as an admin' : ''}. Enter your name to come in.`;
    if (invited) {
      nameInput.value = invited;
      nameInput.readOnly = true;
    }
    (invited ? passwordInput : nameInput).focus();
  } catch {
    // Offline or server unreachable
  }
}

if (codeOrToken) {
  void checkCode(codeOrToken);
} else {
  codeInput.focus();
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.textContent = '';
  const currentCode = codeInput.value.trim();
  const currentName = nameInput.value.trim();
  const currentPass = passwordInput.value;

  if (!currentCode) {
    errorEl.textContent = 'Please enter a Room Code or invite token';
    codeInput.focus();
    return;
  }
  if (!currentName) {
    errorEl.textContent = 'Please enter your name';
    nameInput.focus();
    return;
  }

  submitBtn.disabled = true;
  try {
    const r = await post({
      token: currentCode,
      code: currentCode,
      name: currentName,
      password: currentPass,
    });
    if (!r.ok) {
      errorEl.textContent = r.body.error ?? 'Could not join room';
      return;
    }
    try {
      localStorage.setItem('agent-office.login-name', r.body.name || currentName);
    } catch {
      // storage blocked
    }
    location.replace('/');
  } catch {
    errorEl.textContent = 'Server unreachable';
  } finally {
    submitBtn.disabled = false;
  }
});
